/**
 * File: loop.c
 * ------------
 * Simple program that just runs forever.
 */

#include <stdbool.h>

int main(int argc, char *argv[]) {
  while (true) {;}
  return 0;
}
