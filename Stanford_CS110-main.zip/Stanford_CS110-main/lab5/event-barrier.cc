/**
 * File: event-barrier.cc
 * ----------------------
 * Implements the EventBarrier class.
 */

#include "event-barrier.h"
using namespace std;

EventBarrier::EventBarrier() {}
void EventBarrier::wait() {}
void EventBarrier::lift() {}
void EventBarrier::past() {}
